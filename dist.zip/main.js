"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = require("./infra/logger");
const http_server_1 = __importDefault(require("./http-server"));
var ExitStatus;
(function (ExitStatus) {
    ExitStatus[ExitStatus["Failure"] = 1] = "Failure";
    ExitStatus[ExitStatus["Success"] = 0] = "Success";
})(ExitStatus || (ExitStatus = {}));
async function main() {
    try {
        const httpServer = new http_server_1.default();
        const port = 3000;
        const exitSignals = ["SIGINT", "SIGTERM", "SIGQUIT"];
        exitSignals.map((sig) => process.on(sig, async () => {
            try {
                httpServer.stop();
                logger_1.logger.info("Arret du serveur OK");
                process.exit(ExitStatus.Success);
            }
            catch (error) {
                logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
                process.exit(ExitStatus.Failure);
            }
        }));
        const app = await httpServer.createApp();
        app.listen(port, () => logger_1.logger.info(`Execution sur le port ${port}`));
    }
    catch (error) {
        logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
        process.exit(ExitStatus.Failure);
    }
}
main();
