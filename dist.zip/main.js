"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = require("./infra/logger");
const http_server_1 = __importDefault(require("./http-server"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const controller_1 = require("./app/configuration/controller");
const db_1 = require("./db");
const https_1 = __importDefault(require("https"));
const pem_1 = __importDefault(require("pem"));
var ExitStatus;
(function (ExitStatus) {
    ExitStatus[ExitStatus["Failure"] = 1] = "Failure";
    ExitStatus[ExitStatus["Success"] = 0] = "Success";
})(ExitStatus || (ExitStatus = {}));
async function mainHttp() {
    try {
        const httpServer = new http_server_1.default();
        const port = 3000;
        const exitSignals = ["SIGINT", "SIGTERM", "SIGQUIT"];
        if (!fs_1.default.existsSync(path_1.default.resolve(__dirname, "./public/js", "configuration.js")) && await (0, db_1.isDbExists)() === true)
            (0, controller_1.writeConfig)();
        exitSignals.map((sig) => process.on(sig, async () => {
            try {
                httpServer.stop();
                logger_1.logger.info("Arret du serveur OK");
                process.exit(ExitStatus.Success);
            }
            catch (error) {
                logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
                process.exit(ExitStatus.Failure);
            }
        }));
        const app = await httpServer.createApp();
        app.listen(port, () => logger_1.logger.info(`Serveur HTTP actif sur le port ${port}`));
    }
    catch (error) {
        logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
        process.exit(ExitStatus.Failure);
    }
}
;
async function mainHttps() {
    try {
        const httpServer = new http_server_1.default();
        const port = 3000;
        const exitSignals = ["SIGINT", "SIGTERM", "SIGQUIT"];
        if (!fs_1.default.existsSync(path_1.default.resolve(__dirname, "./public/js", "configuration.js")) && await (0, db_1.isDbExists)() === true)
            (0, controller_1.writeConfig)();
        exitSignals.map((sig) => process.on(sig, async () => {
            try {
                httpServer.stop();
                logger_1.logger.info("Arret du serveur OK");
                process.exit(ExitStatus.Success);
            }
            catch (error) {
                logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
                process.exit(ExitStatus.Failure);
            }
        }));
        pem_1.default.createCertificate({ days: 1, selfSigned: true }, async function (err, keys) {
            if (err) {
                throw err;
            }
            // const app = httpServer.createApp();
            const app = await httpServer.createApp();
            // var app = express()
            https_1.default.createServer({ key: keys.clientKey, cert: keys.certificate }, await app).listen(443);
        });
        const app = await httpServer.createApp();
        app.listen(port, () => logger_1.logger.info(`Serveur HTTPS actif sur le port ${port}`));
    }
    catch (error) {
        logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
        process.exit(ExitStatus.Failure);
    }
}
;
if (process.env.NODE_ENV === 'production')
    mainHttps();
else
    mainHttp();
