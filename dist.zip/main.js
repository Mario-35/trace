"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const logger_1 = require("./infra/logger");
const http_server_1 = __importDefault(require("./http-server"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const controller_1 = require("./app/configuration/controller");
const db_1 = require("./db");
const https_1 = __importDefault(require("https"));
const http_1 = __importDefault(require("http"));
var ExitStatus;
(function (ExitStatus) {
    ExitStatus[ExitStatus["Failure"] = 1] = "Failure";
    ExitStatus[ExitStatus["Success"] = 0] = "Success";
})(ExitStatus || (ExitStatus = {}));
async function main(port) {
    try {
        const server = (0, express_1.default)();
        const httpServer = new http_server_1.default(server);
        const exitSignals = ["SIGINT", "SIGTERM", "SIGQUIT"];
        if (!fs_1.default.existsSync(path_1.default.resolve(__dirname, "./public/js", "configuration.js")) && await (0, db_1.isDbExists)() === true)
            (0, controller_1.writeConfig)();
        exitSignals.map((sig) => process.on(sig, async () => {
            try {
                httpServer.stop();
                logger_1.logger.info("Arret du serveur OK");
                process.exit(ExitStatus.Success);
            }
            catch (error) {
                logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
                process.exit(ExitStatus.Failure);
            }
        }));
        const app = await httpServer.createApp();
        http_1.default.createServer(app).listen(3000, () => {
            logger_1.logger.info(`Serveur HTTP actif sur le port ${3000}`);
        });
        https_1.default.createServer({
            key: fs_1.default.readFileSync(path_1.default.join(__dirname, 'keys/server.key'), 'utf8'),
            cert: fs_1.default.readFileSync(path_1.default.join(__dirname, 'keys/server.crt'), 'utf8'),
            ca: fs_1.default.readFileSync(path_1.default.join(__dirname, 'keys/server.ca'), 'utf8')
        }, app).listen(443, () => {
            logger_1.logger.info(`Serveur HTTPS actif sur le port ${443}`);
        });
    }
    catch (error) {
        logger_1.logger.error(`Arret du serveur avec l'erreur : ${error}`);
        process.exit(ExitStatus.Failure);
    }
}
;
main(3000);
