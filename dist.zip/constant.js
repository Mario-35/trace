"use strict";
/**
 * Constants
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports._NONCE = exports._CONFIG = exports.EConstant = exports.CORS = exports._TYPES = exports.HELMET = void 0;
exports.setConfig = setConfig;
const node_crypto_1 = __importDefault(require("node:crypto"));
exports.HELMET = {
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: false,
    crossOriginOpenerPolicy: false,
    contentSecurityPolicy: (process.env.NODE_ENV === 'production') ? undefined : false
};
exports._TYPES = ["Boues", "Eau", "Invertébrés", "Sol cultivé", "Sol forestier", "Prairie", "Sol"];
exports.CORS = {
    origin: '*',
    methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
};
exports.EConstant = Object.freeze({
    appName: "Trace",
    repository: "https://github.com/Mario-35/Trace",
    branch: "main",
    columnSeparator: "@|@",
    doubleQuotedComa: '",\n"',
    simpleQuotedComa: "',\n'",
    newline: "\r\n",
    tab: "\t",
    return: "\n",
    host: "127.0.0.1",
    pg: "postgres",
    port: 5432,
    voidSql: "SELECT 1=1",
    version: "1.0",
    date: "15-02-2026",
});
exports._CONFIG = {};
function setConfig(input) {
    exports._CONFIG = input;
}
exports._NONCE = node_crypto_1.default.randomBytes(16).toString("base64");
