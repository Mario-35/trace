"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CORS = exports.HELMET = void 0;
exports.HELMET = {
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: false,
    crossOriginOpenerPolicy: false,
};
exports.CORS = {
    origin: '*',
    methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
};
