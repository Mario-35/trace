"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeAllQuotes = void 0;
const removeAllQuotes = (input) => input.replace(/['"]+/g, "");
exports.removeAllQuotes = removeAllQuotes;
