"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.update = update;
const child_process_1 = require("child_process");
async function update() {
    (0, child_process_1.execSync)('curl -L -O https://github.com/Mario-35/trace/raw/refs/heads/main/dist.zip && unzip --fo dist.zip -d ./trace/');
    process.exit(0);
}
