"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRpg = getRpg;
const logger_1 = require("../infra/logger");
let _geo = undefined;
async function getRpgDatas(annee, x, y) {
    let url = 'https://apicarto.ign.fr/api/rpg/v';
    url += annee < 2015 ? '1' : '2';
    url += '?annee=' + annee + '&geom={"type": "Point", "coordinates": [' + x + ', ' + y + ']}';
    return fetch(encodeURI(url), {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    }).then(async (response) => {
        return await response.json().then((res) => {
            try {
                return res["code"] === 400 ? "NOT" : res["features"][0]["properties"]["code_cultu"];
            }
            catch (error) {
                return "NOT";
            }
        });
    }).catch((error) => {
        logger_1.logger.error(error);
    });
}
async function getRpg(x, y) {
    const results = {};
    const maxYear = new Date().getFullYear();
    _geo = undefined;
    for (let year = maxYear - 15; year <= maxYear; year++) {
        results[year] = await getRpgDatas(year, x, y) || "NOT";
    }
    return results;
}
;
