"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escapeSimpleQuotes = void 0;
const escapeSimpleQuotes = (input) => (typeof input === "string") ? input.replace(/[']+/g, "''") : input;
exports.escapeSimpleQuotes = escapeSimpleQuotes;
