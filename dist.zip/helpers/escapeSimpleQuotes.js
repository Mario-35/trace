"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escapeSimpleQuotes = void 0;
const escapeSimpleQuotes = (input) => input.replace(/[']+/g, "''");
exports.escapeSimpleQuotes = escapeSimpleQuotes;
