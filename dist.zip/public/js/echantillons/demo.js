const _DEMOS ={
    "Rien": {},
    "Basic": {
        "type": "Sols cultivé",
        "prelevement": "2026-02-15",
        "programme": "Programme a faire",
        "site": "Site sur la lune",
        "libre": "Un faux diverses",
        "responsable": "De rien",
        "nombre": 9,
        "pays": "France",
        "region": "Bretagne",
        "pointx": "2.549023",
        "pointy": "50.861302",
        "stockage": {"Piece":"2","Batiment":"psn"},
        "cultures": {}
    },
    "Risque": {
        "type": "Sols cultivé",
        "prelevement": "2026-05-15",
        "programme": "informatique",
        "site": "Site a prevoire",
        "libre": "de toute choses",
        "responsable": "Personne",
        "nombre": 9,
        "pays": "France",
        "region": "Normandie",
        "pointx": "1,4312657",
        "pointy": "49,9967718",
        "stockage": {"Piece":"Sous sol","Batiment":"13"},
        "cultures": {}
    },
  "PasInfos": {
    "type": "Sols cultivé",
    "prelevement": "2025-09-27",
    "programme": "Egestas Ligula Nullam Corporation",
    "site": "Site a prevoire",
    "libre": "Phasellus ornare. Fusce mollis. Duis",
    "responsable": "Wayne Curry",
    "nombre": 9,
    "pays": "France",
    "region": "Nord",
    "pointx": "1,6442706",
    "pointy": "50,7160535",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Possible": {
    "type": "Sols cultivé",
    "prelevement": "2026-08-12",
    "programme": "Curabitur Sed Tortor Ltd",
    "site": "Site a prevoire",
    "libre": "elementum, dui quis accumsan convallis,",
    "responsable": "Geoffrey Sherman",
    "nombre": 9,
    "pays": "France",
    "region": "Grand Est",
    "pointx": "4,7256391",
    "pointy": "48,9702311",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Risque2": {
    "type": "Sols cultivé",
    "prelevement": "2025-04-17",
    "programme": "Massa Integer Incorporated",
    "site": "Site a prevoire",
    "libre": "nunc. In at pede. Cras",
    "responsable": "Armando French",
    "nombre": 9,
    "pays": "France",
    "region": "Centre-Val de Loire",
    "pointx": "1,2425996",
    "pointy": "48,4138067",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Possible2": {
    "type": "Sols cultivé",
    "prelevement": "2025-04-21",
    "programme": "Dapibus Id LLP",
    "site": "Site a prevoire",
    "libre": "aliquam adipiscing lacus. Ut nec",
    "responsable": "Demetria Harrison",
    "nombre": 9,
    "pays": "France",
    "region": "Pays de la Loire",
    "pointx": "-0,2269438",
    "pointy": "47,5272638",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
}
