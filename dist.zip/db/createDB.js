"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDB = createDB;
const _1 = require(".");
const base_1 = require("./base");
const asyncForEach_1 = require("../helpers/asyncForEach");
const populate_1 = require("./populate");
const constant_1 = require("../constant");
const toTitleCase_1 = require("../helpers/toTitleCase");
async function createDB(adminPass) {
    const result = {};
    const create = await (0, _1.admin)(adminPass).unsafe("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = 'trace';").then(async (res) => {
        return await (0, _1.admin)(adminPass).unsafe("DROP DATABASE trace").then(async (res) => {
            result["DROP DATABASE"] = "Ok";
            return await (0, _1.admin)(adminPass).unsafe("CREATE DATABASE trace").then(async (res) => {
                result["CREATE DATABASE"] = "Ok";
                return true;
            }).catch(error => {
                result["CREATE DATABASE"] = "Error";
                return false;
            });
        }).catch(async (error) => {
            return await (0, _1.admin)(adminPass).unsafe("CREATE DATABASE trace").then(async (res) => {
                result["CREATE DATABASE"] = "Ok";
                return true;
            }).catch(error => {
                result["CREATE DATABASE"] = "Error";
                return false;
            });
        });
    });
    if (create === false)
        return result;
    const query = [];
    Object.keys(base_1.dataBase).forEach(tableName => {
        const cols = [];
        if (base_1.dataBase[tableName].create === true) {
            Object.keys(base_1.dataBase[tableName].columns).forEach((columnName) => {
                if (String(base_1.dataBase[tableName].columns[columnName]["create"]).trim() !== "")
                    cols.push(columnName + " " + base_1.dataBase[tableName].columns[columnName]["create"]);
            });
            base_1.dataBase[tableName].constraints.forEach(e => cols.push(e));
            query.push(`CREATE TABLE ${tableName} (${cols.join()})${tableName === "echantillons" ? ' PARTITION BY LIST(type)' : ''};`);
        }
    });
    await (0, _1.executeSql)(query).then(async (res) => {
        result["CREATE Tables"] = "Ok";
        // await createDetaultDatas();
        // result["CREATE Default datas"] = "Ok";
    }).catch(error => {
        result["CREATE Tables"] = "Error";
    });
    await (0, asyncForEach_1.asyncForEach)(constant_1._TYPES, async (name) => {
        await (0, _1.executeSql)(`CREATE TABLE IF NOT EXISTS "echantillon_${name.replaceAll(" ", "").toLowerCase()}" PARTITION OF echantillons FOR VALUES IN ('${(0, toTitleCase_1.toTitleCase)(name)}');`).then(() => {
            result["CREATE TABLE partitionned " + name] = "Ok";
        });
    });
    await (0, populate_1.populate)();
    return result;
}
