"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgInsert = createPgInsert;
const _1 = require(".");
function createPgInsert(tableName, values) {
    return `INSERT INTO ${tableName} (${(0, _1.createPgColumns)(tableName, values)}) VALUES (${(0, _1.createPgValues)(tableName, values)})`;
}
