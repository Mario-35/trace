"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgValues = createPgValues;
const _1 = require(".");
const escapeSimpleQuotes_1 = require("../helpers/escapeSimpleQuotes");
const toTitleCase_1 = require("../helpers/toTitleCase");
const base_1 = require("./base");
function createPgValues(tableName, values, columns) {
    const results = [];
    (columns || (0, _1.getColumns)(tableName)).forEach(column => {
        if (values[column] && values[column] !== "") {
            switch (base_1.dataBase[tableName].columns[column].type) {
                case "text[]":
                    (typeof values[column] === "string")
                        ? results.push(`{"${values[column].split(',').join('","')}"}`)
                        : results.push(`{"${values[column]}"}`);
                    break;
                case "json":
                    results.push(`${JSON.stringify(values[column])}`);
                    break;
                // case "text":
                case "text":
                    results.push((0, escapeSimpleQuotes_1.escapeSimpleQuotes)((0, toTitleCase_1.toTitleCase)(values[column])));
                    break;
                //       if (dataBase[tableName].columns[column].create.includes('varchar')) {
                //             const max = dataBase[tableName].columns[column].create.split('(')[1].split(')')[0];
                //             results.push(escapeSimpleQuotes(values[column]).substring(0,+max));
                //       } else results.push(escapeSimpleQuotes(values[column]));
                //       break;                                                
                default:
                    results.push((0, escapeSimpleQuotes_1.escapeSimpleQuotes)(values[column]));
            }
        }
    });
    return `'${results.join("','")}'`;
}
