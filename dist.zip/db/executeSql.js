"use strict";
/**
 * executeSql
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSql = void 0;
const _1 = require(".");
const executeSqlOne = async (query) => {
    return new Promise(async function (resolve, reject) {
        await _1.sql
            .unsafe(query)
            .then((res) => {
            resolve(res);
        })
            .catch((err) => {
            console.log(err);
            reject(err);
        });
    });
};
const executeSqlMulti = async (queries) => {
    return new Promise(async function (resolve, reject) {
        await _1.sql
            .begin((sql) => queries.map(async (query) => {
            await sql.unsafe(query);
        }))
            .then((res) => {
            resolve(res);
        })
            .catch((err) => {
            console.log(err);
            reject(err);
        });
    });
};
const executeSql = async (query) => (typeof query === "string" ? executeSqlOne(query) : executeSqlMulti(query));
exports.executeSql = executeSql;
