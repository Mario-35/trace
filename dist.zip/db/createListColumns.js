"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createListColumns = createListColumns;
const _1 = require(".");
const base_1 = require("./base");
function createListColumns(tableName) {
    return (0, _1.getColumns)(tableName)
        .filter(column => base_1.dataBase[tableName].columns[column].list === true)
        .map(column => base_1.dataBase[tableName].columns[column].calculate
        ? `${base_1.dataBase[tableName].columns[column].calculate} AS ${column}`
        : `"${column}"`)
        .filter(e => e !== "")
        .join();
}
