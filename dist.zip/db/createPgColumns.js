"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgColumns = createPgColumns;
const _1 = require(".");
function createPgColumns(tableName, values) {
    return (0, _1.getColumns)(tableName).map(column => values[column] ? `"${column}"` : '').filter(e => e !== "").join();
}
