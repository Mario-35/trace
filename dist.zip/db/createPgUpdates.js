"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgUpdates = createPgUpdates;
const _1 = require(".");
const base_1 = require("./base");
function createPgUpdates(tableName, values) {
    const results = [];
    const columns = (0, _1.getColumns)(tableName);
    columns.forEach(column => {
        if (values[column]) {
            switch (base_1.dataBase[tableName].columns[column].type) {
                case "text[]":
                    results.push(`"${column}" = '{"${values[column].split(',').join('","')}"}'`);
                    break;
                case "json":
                    results.push(`"${column}" = '${JSON.stringify(values[column])}'`);
                    break;
                default:
                    results.push(`"${column}" = '${values[column]}'`);
            }
        }
    });
    return results.join();
}
