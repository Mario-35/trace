"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Documentation = void 0;
const constant_1 = require("../../constant");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const core_1 = require("./core");
class Documentation extends core_1.CoreHtmlView {
    constructor(page) {
        super();
        this.createExportHtmlString(page);
    }
    createExportHtmlString(page) {
        const pg = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../../public/documentation/", page))
            .toString()
            .split(constant_1.EConstant.newline)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        this._HTMLResult = [
            '<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Gestion de échantillons</title>',
            '    <link rel="stylesheet" href="../css/splitter.css">',
            '    <link rel="stylesheet" href="../css/bootstrap.css">',
            '    <link rel="stylesheet" href="../css/menu.css">',
            '</head>',
            '<body>',
            '	<header id="splitter-nav-site" class="splitter-nav-site"></header>',
            '    <main class="main-view">',
            '        <div class="splitter-nav-view" id="left-pane"></div>',
            '        <div class="v-drag" id="separator"></div>',
            '        <div class="content" id="right-pane">',
            ...pg,
            '   </div>',
            '   </main>',
            '</body>',
            '<script src="../js/all.js"></script>',
            '<script src="../js/configuration.js"></script>',
            '<script src="../js/constants.js"></script>',
            '<script src="../js/common/splitter.js"></script>',
            '<script src="../js/common/menu.js"></script>',
            '</html>'
        ].map((e) => e.trim());
    }
    toString() {
        return super.toString();
    }
}
exports.Documentation = Documentation;
