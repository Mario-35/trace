"use strict";
/**
 * HTML Print for API.
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Print = void 0;
const constant_1 = require("../../constant");
const core_1 = require("./core");
/**
 * Print Class for HTML View
 */
class Print extends core_1.CoreHtmlView {
    datas;
    constructor(type, datas) {
        super();
        this.datas = datas;
        if (type === "echantillon")
            this.createPrintEchantillonHtmlString();
        else if (type === "passeport")
            this.createPrintPasseportHtmlString();
    }
    createPrintPasseportHtmlString() {
        this._HTMLResult = ['<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '<meta charset="UTF-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '<title>Impression des passeports</title>',
            this.getFile("./css/print.css"),
            this.getFile("./css/passeport.css"),
            '</head>',
            '<body>',
            '<div class="content" id="passeportsContent"></div>',
            '</body> ',
            `<script nonce="${constant_1._NONCE}">`,
            `_DATAPI = ${JSON.stringify(this.datas)}`,
            '</script>',
            this.getFile("./js/configuration.js"),
            this.getFile("./js/constants.js"),
            this.getFile("./js/api/print.js"),
            `<script nonce="${constant_1._NONCE}">start()</script>`,
            '</html>'].map((e) => e.trim());
    }
    createPrintEchantillonHtmlString() {
        this._HTMLResult = ['<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '<meta charset="UTF-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '<title>Gestion des étiquettes</title>',
            this.getFile("./css/print.css"),
            this.getFile("./css/echantillon.css"),
            '</head>',
            '<body>',
            '<div class="content" id="echantillonsContent"></div>',
            '</body> ',
            `<script nonce="${constant_1._NONCE}">`,
            `_DATAPI = ${JSON.stringify(this.datas)}`,
            '</script>',
            this.getFile("./js/configuration.js"),
            this.getFile("./js/constants.js"),
            this.getFile("./js/libs/JsBarcode.all.min.js"),
            this.getFile("./js/api/print.js"),
            `<script nonce="${constant_1._NONCE}">start()</script>`,
            '</html>'].map((e) => e.trim());
    }
    toString() {
        return super.toString();
    }
}
exports.Print = Print;
