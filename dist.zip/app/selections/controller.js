"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSelection = addSelection;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
async function addSelection(values) {
    return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.selections.name} (ids) VALUES ('{${values}}') RETURNING id`);
}
