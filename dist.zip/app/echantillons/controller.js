"use strict";
/**
 * Echantillons controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addEchantillon = addEchantillon;
exports.updateEchantillon = updateEchantillon;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
async function addEchantillon(values) {
    // store all queries
    const queries = [];
    // store analyzes case nombreOuAnalyses is true
    let analyzes = [];
    // store identification for return request
    let tmpCode = undefined;
    // Create list of columns
    const tableColumns = Object.keys(base_1.dataBase.echantillons.columns).filter(e => values[e]);
    // Create list insert into
    const insertInto = tableColumns;
    // Get the start number
    const start = +values["numero"];
    // If excel instert
    if (values["excel"]) {
        // get the excel file saved
        const excelFile = await (0, db_1.sql) `SELECT * FROM ${(0, db_1.sql)("excels")} WHERE id = ${+values["excel"]}`;
        // Create list of excel columns
        const excelCols = excelFile[0]["datas"]["columns"];
        // lopp excel lines
        Object.values(excelFile[0]["datas"]["datas"]).forEach((tmp, index) => {
            // clone line
            const tempVal = JSON.parse(JSON.stringify(values));
            // modify the lines with excel values
            Object.keys(excelCols).forEach(key => {
                delete tempVal[key];
                tempVal[key] = tmp[excelCols[key]]; // TODO CHANGE VALUES
            });
            // create identification
            if (tempVal["identification"])
                tempVal["identification"] = values["identification"].slice(0, 12) + String(+tmp[excelCols["echantillon"]] || index + start).padStart(4, '0');
            if (!tmpCode)
                tmpCode = values["identification"].slice(0, 12);
            // Go
            queries.push(`INSERT INTO echantillons (${insertInto.map(e => `"${e}"`).join()}) VALUES (${(0, db_1.createPgValues)("echantillons", tempVal, insertInto)})`);
        });
    }
    else {
        // Get the nb of lines to insert
        let nb = +values["nombre"];
        // loop on analyses
        if (!values["nombreOuAnalyses"]) {
            analyzes = values["analyses"].split(",");
            nb = analyzes.length;
        }
        // create start string for identification
        tmpCode = values["identification"].slice(0, 12);
        // create identification codes
        const codesIdentification = [];
        for (var i = 0; i < nb; i++)
            codesIdentification.push(tmpCode + String(i + start).padStart(4, '0'));
        // loop in identifications
        codesIdentification.forEach((identification, i) => {
            values["identification"] = identification;
            if (!values["nombreOuAnalyses"])
                values["analyses"] = analyzes[i];
            queries.push(`INSERT INTO echantillons (${insertInto.join()}) VALUES (${(0, db_1.createPgValues)("echantillons", values)})`);
        });
        // execute all queries
        return new Promise(async function (resolve, reject) {
            return (0, db_1.executeSql)(queries).then(async () => {
                // create selection return (usefull for print stickers)
                const selectionId = await db_1.sql.unsafe(`INSERT INTO selections (ids) SELECT ARRAY_AGG(id) FROM echantillons WHERE identification IN ('${codesIdentification.join("','")}') RETURNING id`);
                resolve({ selection: selectionId[0].id });
            }).catch(error => {
                reject(error);
            });
        });
    }
    // execute all queries
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(queries)
            .then(async () => {
            resolve({ identification: tmpCode });
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
async function updateEchantillon(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`UPDATE echantillons SET ${(0, db_1.createPgUpdates)("echantillons", values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, db_1.sql) `SELECT * FROM echantillons WHERE id = ${id}`;
            resolve(ret);
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
