"use strict";
/**
 * App index
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.campagnesRoutes = exports.rpgsRoutes = exports.selectionsRoutes = exports.excelsRoutes = exports.configRoutes = exports.pagesRoutes = exports.evenementsRoutes = exports.sitesRoutes = exports.passeportsRoutes = exports.echantillonsRoutes = void 0;
var echantillonsRoutes_1 = require("./echantillons/echantillonsRoutes");
Object.defineProperty(exports, "echantillonsRoutes", { enumerable: true, get: function () { return echantillonsRoutes_1.echantillonsRoutes; } });
var passeportsRoutes_1 = require("./passeports/passeportsRoutes");
Object.defineProperty(exports, "passeportsRoutes", { enumerable: true, get: function () { return passeportsRoutes_1.passeportsRoutes; } });
var sitesRoutes_1 = require("./sites/sitesRoutes");
Object.defineProperty(exports, "sitesRoutes", { enumerable: true, get: function () { return sitesRoutes_1.sitesRoutes; } });
var evenementsRoutes_1 = require("./evenements/evenementsRoutes");
Object.defineProperty(exports, "evenementsRoutes", { enumerable: true, get: function () { return evenementsRoutes_1.evenementsRoutes; } });
var pagesRoutes_1 = require("./pages/pagesRoutes");
Object.defineProperty(exports, "pagesRoutes", { enumerable: true, get: function () { return pagesRoutes_1.pagesRoutes; } });
var configRoutes_1 = require("./configuration/configRoutes");
Object.defineProperty(exports, "configRoutes", { enumerable: true, get: function () { return configRoutes_1.configRoutes; } });
var excelsRoutes_1 = require("./excels/excelsRoutes");
Object.defineProperty(exports, "excelsRoutes", { enumerable: true, get: function () { return excelsRoutes_1.excelsRoutes; } });
var selectionsRoutes_1 = require("./selections/selectionsRoutes");
Object.defineProperty(exports, "selectionsRoutes", { enumerable: true, get: function () { return selectionsRoutes_1.selectionsRoutes; } });
var rpgsRoutes_1 = require("./rpg/rpgsRoutes");
Object.defineProperty(exports, "rpgsRoutes", { enumerable: true, get: function () { return rpgsRoutes_1.rpgsRoutes; } });
var campagnesRoutes_1 = require("./campagnes/campagnesRoutes");
Object.defineProperty(exports, "campagnesRoutes", { enumerable: true, get: function () { return campagnesRoutes_1.campagnesRoutes; } });
