"use strict";
/**
 * Rpg routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.rpgsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("./controller");
const db_1 = require("../../db");
exports.rpgsRoutes = (0, express_1.Router)();
// Get rpg
exports.rpgsRoutes.get("/rpg", async (req, res) => {
    const tmp = req.url.split("?pos=")[1].split(",");
    return await (0, controller_1.getRpg)(tmp[0], tmp[1]).then(async (rpg) => {
        const codes = await (0, db_1.executeSqlValues)(`SELECT CONCAT('"', code, '" : "',valeur, '"') FROM rpg WHERE code IN ('${Array.from(new Set(Object.values(rpg).map(item => item))).join("','")}')`);
        return res.status(200).json({
            values: rpg,
            codes: codes,
        });
    }).catch(error => {
        console.log(error);
        return res.status(404).json({ "error": error.detail });
    });
});
