"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.v1Routes = void 0;
const express_1 = require("express");
const http_1 = require("./example-users/http");
exports.v1Routes = (0, express_1.Router)();
// Registra todas as rotas da v1
exports.v1Routes.use("/users", http_1.userRoutesV1);
// Rota de informação da versão
exports.v1Routes.get("/", (_req, res) => {
    res.json({
        version: "v1",
        description: "API version 1"
    });
});
