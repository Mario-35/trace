"use strict";
/**
 * Pages routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.pagesRoutes = void 0;
const express_1 = require("express");
const main_1 = require("../../html/class/main");
const print_1 = require("../../html/class/print");
const controller_1 = require("../../controller");
const list_1 = require("../../html/class/list");
const configuration_1 = require("../../html/class/configuration");
const db_1 = require("../../db");
const add_1 = require("../../html/class/add");
const constant_1 = require("../../constant");
const base_1 = require("../../db/base");
const update_1 = require("../../helpers/update");
exports.pagesRoutes = (0, express_1.Router)();
// Get all echantillons
exports.pagesRoutes.get("/index", async (req, res) => {
    const html = new main_1.Index();
    res.send(html.toString());
});
// add sample
exports.pagesRoutes.get("/" + base_1.dataBase.echantillons.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.echantillons.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add event
exports.pagesRoutes.get("/" + base_1.dataBase.evenements.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.evenements.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add site
exports.pagesRoutes.get("/" + base_1.dataBase.sites.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.sites.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add passeport
exports.pagesRoutes.get("/" + base_1.dataBase.passeports.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.passeports.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// sites page
exports.pagesRoutes.get("/" + base_1.dataBase.sites.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.sites.name);
    res.send(html.toString());
});
// evenements page
exports.pagesRoutes.get("/" + base_1.dataBase.evenements.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.evenements.name);
    res.send(html.toString());
});
// passeports page
exports.pagesRoutes.get("/" + base_1.dataBase.passeports.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.passeports.name);
    res.send(html.toString());
});
// campagnes page
exports.pagesRoutes.get("/" + base_1.dataBase.campagnes.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.campagnes.name);
    res.send(html.toString());
});
// echantillons page
exports.pagesRoutes.get("/" + base_1.dataBase.echantillons.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.echantillons.name);
    res.send(html.toString());
});
// print sample sticker
exports.pagesRoutes.get("/update", async (req, res) => {
    res.status(201).send(await (0, update_1.update)());
});
// print sample sticker
exports.pagesRoutes.get("/new", async (req, res) => {
    res.status(201).send({ "new": "ok ca marche" });
});
// print sample sticker
exports.pagesRoutes.get("/print/:type", async (req, res) => {
    switch (req.params.type) {
        case 'echantillon':
            const html = new print_1.Print("echantillon", [constant_1._CONFIG]);
            return res.set('Content-Type', 'text/html').send(html.toString());
    }
});
// prints
exports.pagesRoutes.get("/print/:type/:id", async (req, res) => {
    switch (req.params.type) {
        case 'config':
            if (constant_1._CONFIG) {
                const html = new print_1.Print("echantillon", constant_1._CONFIG);
                return res.set('Content-Type', 'text/html').send(html.toString());
            }
            else
                return res.status(404).json({ "error": "no config" });
        case base_1.dataBase.echantillons.singular:
            return await (0, controller_1.readId)(base_1.dataBase.echantillons.name, +req.params.id).then((echantillon) => {
                const html = new print_1.Print("echantillon", echantillon);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case base_1.dataBase.selections.singular:
            return await (0, controller_1.readId)(base_1.dataBase.selections.name, +req.params.id).then(async (selection) => {
                return await (0, controller_1.readIds)(base_1.dataBase.echantillons.name, selection[0].ids).then(async (all) => {
                    const html = new print_1.Print("echantillon", all);
                    res.set('Content-Type', 'text/html').send(html.toString());
                }).catch(error => {
                    console.error(error);
                    return res.status(404).json({ "error": error.detail });
                });
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case base_1.dataBase.passeports.singular:
            return await (0, controller_1.readId)(base_1.dataBase.passeports.name, +req.params.id).then((passeport) => {
                const html = new print_1.Print("passeport", passeport);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'identification':
            return await (0, db_1.executeSql)(`SELECT * FROM ${base_1.dataBase.echantillons.name} WHERE identification LIKE '${req.params.id.slice(0, 12)}%'`).then(async (all) => {
                const html = new print_1.Print("echantillon", all);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'echantillonPasseport':
            console.log("ici todo");
        default:
            break;
    }
    ;
});
exports.pagesRoutes.post("/SaveConfig", async (req, res) => {
    (0, constant_1.setConfig)(req.body);
    res.status(201).send();
});
// configuration page
exports.pagesRoutes.get("/configuration.html", async (req, res) => {
    res.send(new configuration_1.Configuration().toString());
});
