"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addEvenement = addEvenement;
exports.updateEvenement = updateEvenement;
const db_1 = require("../../db");
async function addEvenement(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgInsert)("evenements", values)} RETURNING id`)
            .then(async (res) => {
            resolve(res[0].id);
        }).catch(error => {
            reject(error);
        });
    });
}
;
async function updateEvenement(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)("evenements", values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, db_1.sql) `SELECT * FROM evenements WHERE id = ${id}`;
            resolve(ret[0].id);
        }).catch(error => {
            reject(error);
        });
    });
}
;
