"use strict";
/**
 * Campagnes routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.campagnesRoutes = void 0;
const express_1 = require("express");
const db_1 = require("../../db");
exports.campagnesRoutes = (0, express_1.Router)();
// Get all campagnes
exports.campagnesRoutes.get("/list/campagnes", async (req, res) => {
    return await (0, db_1.executeSql)(`WITH src AS (SELECT DISTINCT ON(SUBSTRING (identification FROM 1 FOR 12)) SUBSTRING (identification FROM 1 FOR 12) as id, type, dossier, creation, prelevement, programme, site, responsable FROM echantillons) SELECT src.id AS id, ${(0, db_1.createListColumns)("campagnes")} FROM src ORDER BY creation`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// not sure is used
exports.campagnesRoutes.get("/campagnes", async (req, res) => {
    return await (0, db_1.executeSql)(`WITH src AS (SELECT DISTINCT(SUBSTRING (identification FROM 1 FOR 12)) AS id, type, dossier, creation, prelevement, programme, site, responsable FROM echantillons) SELECT *, (SELECT COUNT(*) FROM echantillons WHERE identification LIKE src.id || '%') AS echantillons FROM echantillons ORDER BY creation`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
