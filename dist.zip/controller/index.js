"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readAll = readAll;
exports.readAlSearch = readAlSearch;
exports.readEchantillons = readEchantillons;
exports.readId = readId;
exports.readIds = readIds;
exports.addSelection = addSelection;
exports.setConfiguration = setConfiguration;
exports.getConfiguration = getConfiguration;
exports.verifyBody = verifyBody;
exports.addEchantillon = addEchantillon;
exports.addPasseport = addPasseport;
exports.searchPasseport = searchPasseport;
exports.updateEchantillon = updateEchantillon;
exports.updatePasseport = updatePasseport;
exports.deleteId = deleteId;
exports.addExcel = addExcel;
const db_1 = require("../db");
const executeSql_1 = require("../db/executeSql");
const escapeSimpleQuotes_1 = require("../helpers/escapeSimpleQuotes");
const base = {
    "passeports": {
        "columns": {
            "annee": "number",
            "nom": "text",
            "code": "text",
            "tracabilite": "number",
            "identifiant": "text",
            "fichier": "text",
            "origine": "text",
        }
    },
    "configuration": {
        "columns": {
            "params": "jsonb",
        }
    },
    "excels": {
        "columns": {
            "datas": "jsonb",
        }
    },
    "echantillons": {
        "columns": {
            "type": "text",
            "programme": "text",
            "site": "text",
            "responsable": "text",
            "identification": "text",
            "parent": "text",
            "libre": "text",
            "prelevement": "date",
            "peremption": "date",
            "pays": "text",
            "region": "text",
            "pointx": "text",
            "pointy": "text",
            "passeport": "number",
            "cultures": "jsonb",
            "etiquette": "jsonb",
            "stockage": "jsonb",
            "etat": "text"
        }
    }
};
async function readAll(table) {
    return await (0, db_1.sql) `SELECT * FROM ${(0, db_1.sql)(table)}`;
}
;
async function readAlSearch(table, search) {
    const tableColumns = Object.keys(base[table]["columns"]);
    return await db_1.sql.unsafe(`SELECT * FROM ${table} WHERE ${tableColumns.map(e => `"${e}" LIKE '%${search}%'`).join(" OR ")}`);
}
;
async function readEchantillons() {
    return await (0, db_1.sql) `SELECT id, programme, site, responsable, prelevement, identification, etat FROM echantillons ORDER BY identification`;
}
;
async function readId(table, id) {
    return await (0, db_1.sql) `SELECT * FROM ${(0, db_1.sql)(table)} WHERE id = ${id}`;
}
;
async function readIds(table, ids) {
    return await db_1.sql.unsafe(`SELECT * FROM ${table} WHERE id IN (${ids.join()})`);
}
;
async function addSelection(values) {
    return await (0, executeSql_1.executeSql)(`INSERT INTO selections (ids) VALUES ('{${values}}') RETURNING id`);
}
async function setConfiguration(values) {
    return await (0, executeSql_1.executeSql)(`UPDATE configuration SET params='${values}'::jsonb WHERE nom = 'config'`);
}
async function getConfiguration() {
    return await (0, executeSql_1.executeSql)(`SELECT params FROM configuration WHERE nom = 'config'`);
}
function verifyBody(values) {
    try {
        if (!values)
            return undefined;
        if (Object.keys(values).length < 1)
            return undefined;
    }
    catch (error) {
        console.log(error);
        return undefined;
    }
    return values;
}
async function addEchantillon(values) {
    const queries = [];
    let tmpCode = undefined;
    // Create list of columns
    const tableColumns = Object.keys(base.echantillons.columns);
    // Create list insert into
    const insertInto = tableColumns.map(e => `"${e}"`);
    // If excel instert
    if (values["excel"]) {
        // get the excel file saved
        const excelFile = await readId("excels", +values["excel"]);
        // Create list of excel columns
        const excelCols = excelFile[0]["datas"]["columns"];
        // lopp excel lines
        Object.values(excelFile[0]["datas"]["datas"]).forEach((tmp) => {
            // clone line
            const tempVal = JSON.parse(JSON.stringify(values));
            // modify the lines with excel values
            Object.keys(excelCols).forEach(key => {
                delete tempVal[key];
                tempVal[key] = tmp[excelCols[key]]; // TODO CHANGE VALUES
            });
            // create identification
            if (tempVal["identification"])
                tempVal["identification"] = values["identification"].slice(0, 12) + String(+tmp[excelCols["echantillon"]]).padStart(4, '0');
            if (!tmpCode)
                tmpCode = values["identification"].slice(0, 12);
            // const tmpCode: string =  values["identification" as keyof object].slice(0,12);
            // Create list insert values
            const vals = tableColumns.map(e => tempVal[e]).map(e => `'${e}'`);
            // Go
            queries.push(`INSERT INTO echantillons (${insertInto.join()}) VALUES (${vals.join()})`);
        });
    }
    else {
        // Get the nb of lines to insert
        const nb = +values["nombre"];
        // Get the start number
        const start = +values["numero"];
        // create start string for identification
        tmpCode = values["identification"].slice(0, 12);
        // create identification codes
        const codesIdentification = [];
        for (var i = 0; i <= nb; i++)
            codesIdentification.push(tmpCode + String(i + start).padStart(4, '0'));
        // loop in identifications
        codesIdentification.forEach((identification) => {
            values["identification"] = identification;
            // Go
            queries.push(`INSERT INTO echantillons (${insertInto.join()}) VALUES (${tableColumns.map(e => values[e]).map(e => `'${e}'`).join()})`);
        });
    }
    (0, executeSql_1.executeSql)(queries);
    return { identification: tmpCode };
}
;
async function addPasseport(values) {
    const cols = Object.keys(base.passeports.columns);
    return (0, executeSql_1.executeSql)(`SELECT max(tracabilite) FROM passeports WHERE annee = '${values["annee"]}'`).then(async (res) => {
        const tmp = res[0]["max"];
        values["tracabilite"] = isNaN(+tmp) ? 1 : +tmp + 1;
        const datas = cols.map(e => isNaN(values[e]) ? (0, escapeSimpleQuotes_1.escapeSimpleQuotes)(values[e]) : values[e]);
        return await (0, executeSql_1.executeSql)(`INSERT INTO passeports (${cols.map(e => `"${e}"`).join()}) VALUES (${datas.map(e => `'${e}'`).join()}) RETURNING id`);
    });
}
;
async function searchPasseport(annee) {
    return await (0, executeSql_1.executeSql)(`SELECT * from passeports where annee = '${annee}'`);
}
;
async function updateEchantillon(values, id) {
    const cols = Object.keys(base.echantillons.columns);
    const datas = cols.filter(e => values[e]);
    return await (0, executeSql_1.executeSql)(`UPDATE echantillons SET ${datas.map(e => `"${e}" = '${values[e]}'`).join()} WHERE id = ${id}`)
        .then(async (res) => {
        return await (0, db_1.sql) `SELECT * FROM echantillons WHERE id = ${id}`;
    });
}
;
async function updatePasseport(values, id) {
    const cols = Object.keys(base.passeports.columns);
    const datas = cols.filter(e => values[e]);
    return await (0, executeSql_1.executeSql)(`UPDATE passeports SET ${datas.map(e => `"${e}" = '${values[e]}'`).join()} WHERE id = ${id}`)
        .then(async (res) => {
        return await (0, db_1.sql) `SELECT * FROM passeports WHERE id = ${id}`;
    });
}
;
async function deleteId(table, id) {
    return await (0, db_1.sql) `DELETE FROM ${(0, db_1.sql)(table)} WHERE id = ${id}`;
}
;
async function addExcel(values) {
    return await (0, executeSql_1.executeSql)(`INSERT INTO excels (datas) VALUES ('${(0, escapeSimpleQuotes_1.escapeSimpleQuotes)(JSON.stringify(values))}') RETURNING id`);
}
