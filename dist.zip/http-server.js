"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const multer_1 = __importDefault(require("multer"));
const compression_1 = __importDefault(require("compression"));
const path_1 = __importDefault(require("path"));
const logger_1 = require("./infra/logger");
const getRpg_1 = require("./helpers/getRpg");
const controller_1 = require("./controller");
const constant_1 = require("./constant");
const db_1 = require("./db");
const createDB_1 = require("./helpers/createDB");
class HttpServer {
    app;
    storage;
    upload;
    _datas;
    constructor() {
        this.app = (0, express_1.default)();
        this.storage = multer_1.default.memoryStorage();
        this.upload = (0, multer_1.default)({ storage: this.storage });
    }
    async createApp() {
        this.loadMiddlewares();
        this.loadRoutes();
        return this.app;
    }
    async stop() {
        logger_1.logger.info("Arret..");
    }
    loadMiddlewares() {
        this.app.use((0, cors_1.default)());
        this.app.use((0, helmet_1.default)(constant_1.HELMET));
        this.app.use(express_1.default.json({ limit: '50mb' }));
        // this.app.use(express.static('public'));
        this.app.use(express_1.default.static(path_1.default.join(__dirname, 'public')));
        this.app.use(express_1.default.json());
        this.app.use(express_1.default.urlencoded({ extended: true }));
        this.app.use((0, compression_1.default)());
    }
    loadRoutes() {
        this.app.get("/", async (_req, res) => {
            res.json({
                message: "Serveur actif...",
            });
        });
        // Get test
        this.app.get("/init/:password", async (_req, res) => {
            res.status(200).json((0, createDB_1.createDB)(_req.params["password"]));
        });
        // ########################################################
        // #                        FILES                         #
        // ########################################################
        // Route to upload an image
        this.app.post('/upload', this.upload.single('image'), async (_req, res) => {
            if (_req.file)
                try {
                    const imageBuffer = _req.file.buffer;
                    const filename = _req.file.originalname;
                    const result = await db_1.sql.unsafe('INSERT INTO fichiers (fichier, nom) VALUES ($1, $2) RETURNING id', [imageBuffer, filename]);
                    res.json(result[0]);
                }
                catch (err) {
                    console.error(err);
                    res.status(500).send('Error uploading file');
                }
        });
        this.app.get("/download/:id", async (_req, res) => {
            return await await db_1.sql.unsafe(`SELECT fichier FROM fichiers WHERE id = ${+_req.params.id}`).then((fichier) => {
                return res.status(200).json(fichier);
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        this.app.get("/excel/:id", async (_req, res) => {
            return await (0, controller_1.readId)("excels", +_req.params.id).then((excel) => {
                return excel.length > 0
                    ? res.status(200).json(excel[0].datas)
                    : res.status(404).json({ "code": 404, "message": "Not Found" });
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        this.app.post("/excel", async (_req, res) => {
            return await (0, controller_1.addExcel)(_req.body).then((excel) => {
                return res.status(201).json(excel);
            }).catch(error => {
                return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
            });
        });
        this.app.get("/health", async (_req, res) => {
            res.status(200).json({
                status: "ok",
                timestamp: new Date().toISOString(),
                uptime: process.uptime()
            });
        });
        // Get all echantillons
        this.app.get("/rpg", async (_req, res) => {
            const tmp = _req.url.split("?pos=")[1].split(",");
            return await (0, getRpg_1.getRpg)(tmp[0], tmp[1]).then((rpg) => {
                return res.status(200).json(rpg);
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // ########################################################
        // #                     ECHANTILLONS                     #
        // ########################################################
        // Get all echantillons
        this.app.get("/echantillons", async (_req, res) => {
            const passeports = await (0, controller_1.readEchantillons)();
            res.status(200).json(passeports);
        });
        // Get one echantillon
        this.app.get("/echantillon/:id", async (_req, res) => {
            return await (0, controller_1.readId)("echantillons", +_req.params.id).then((echantillon) => {
                return echantillon.length > 0
                    ? res.status(200).json(echantillon[0])
                    : res.status(404).json({ "code": 404, "error": "Not Found" });
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // Create one echantillon
        this.app.post("/echantillon", async (_req, res) => {
            return await (0, controller_1.addEchantillon)(_req.body).then((echantillon) => {
                return res.status(201).json(echantillon);
            }).catch(error => {
                return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
            });
        });
        // Update one echantillon
        this.app.patch("/echantillon/:id", async (_req, res) => {
            const echantillon = await (0, controller_1.updateEchantillon)(_req.body, +_req.params.id);
            res.status(201).json(echantillon);
        });
        // delete one echantillon
        this.app.delete("/echantillon/:id", async (_req, res) => {
            return await (0, controller_1.deleteId)("echantillons", +_req.params.id).then((nothing) => {
                return res.status(203).json();
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // ########################################################
        // #                    CONFIGURATION                     #
        // ########################################################
        this.app.post("/configuration", async (_req, res) => {
            const values = (0, controller_1.verifyBody)(_req.body);
            if (values) {
                return await (0, controller_1.setConfiguration)(values).then((configuration) => {
                    return res.status(201).json(configuration);
                }).catch(error => {
                    return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
                });
            }
            else
                res.status(400).json({ "code": 400, "error": "Bad Request" });
        });
        this.app.get("/configuration", async (_req, res) => {
            return await (0, controller_1.getConfiguration)().then((configuration) => {
                return res.status(200).json(configuration[0].params);
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // ########################################################
        // #                      selection                       #
        // ########################################################
        // Get selection
        this.app.get("/selection/:id", async (_req, res) => {
            return await (0, controller_1.readId)("selections", +_req.params.id).then(async (selection) => {
                return await (0, controller_1.readIds)("echantillons", selection[0].ids).then(async (all) => {
                    return res.status(200).json(all);
                }).catch(error => {
                    return res.status(404).json({ "error": error.detail });
                });
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // Create one selection
        this.app.post("/selection", async (_req, res) => {
            return await (0, controller_1.addSelection)(_req.body.ids).then((selection) => {
                return res.status(201).json(selection);
            }).catch(error => {
                return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
            });
        });
        // ########################################################
        // #                      PASSEPORTS                      #
        // ########################################################
        // Get all passeports
        this.app.get("/passeports", async (_req, res) => {
            if (_req.query.search)
                return await (0, controller_1.readAlSearch)("passeports", String(_req.query.search)).then((passeport) => {
                    return res.status(200).json(passeport);
                }).catch(error => {
                    return res.status(404).json({ "error": error.detail });
                });
            else
                return await (0, controller_1.readAll)("passeports").then((passeport) => {
                    return res.status(200).json(passeport);
                }).catch(error => {
                    return res.status(404).json({ "error": error.detail });
                });
        });
        // Get one passeport
        this.app.get("/passeport/:id", async (_req, res) => {
            return await (0, controller_1.readId)("passeports", +_req.params.id).then((passeport) => {
                return passeport.length > 0
                    ? res.status(200).json(passeport[0])
                    : res.status(404).json({ "code": 404, "error": "Not Found" });
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // Create one passeport
        this.app.post("/passeport", async (_req, res) => {
            const values = (0, controller_1.verifyBody)(_req.body);
            if (values) {
                return await (0, controller_1.addPasseport)(values).then((passeport) => {
                    return res.status(201).json(passeport[0]);
                }).catch(error => {
                    console.log(error);
                    return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
                });
            }
            else
                res.status(400).json({ "code": 400, "error": "Bad Request" });
        });
        // Update one passeport
        this.app.patch("/passeport/:id", async (_req, res) => {
            return await (0, controller_1.updatePasseport)(_req.body, +_req.params.id).then((passeport) => {
                return res.status(201).json(passeport);
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // delete one passeport
        this.app.delete("/passeport/:id", async (_req, res) => {
            return await (0, controller_1.deleteId)("passeports", +_req.params.id).then((nothing) => {
                return res.status(203).json();
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        this.app.use((req, res) => {
            res.status(404).json({
                error: {
                    code: "ENDPOINT_NOT_FOUND",
                    message: "Endpoint not found",
                    path: req.originalUrl,
                }
            });
        });
    }
}
exports.default = HttpServer;
