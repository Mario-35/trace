"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const pino_1 = __importDefault(require("pino"));
const logsDir = path_1.default.resolve("logs");
if (!fs_1.default.existsSync(logsDir)) {
    fs_1.default.mkdirSync(logsDir, { recursive: true });
}
exports.logger = (0, pino_1.default)({
    level: "info",
    base: undefined,
    timestamp: pino_1.default.stdTimeFunctions.isoTime,
    transport: process.env.NODE_ENV === "production"
        ? {
            targets: [
                {
                    target: "pino/file",
                    options: { destination: path_1.default.join(logsDir, "error.log") },
                    level: "error"
                },
                {
                    target: "pino/file",
                    options: { destination: path_1.default.join(logsDir, "info.log") },
                    level: "info"
                }
            ]
        }
        : {
            target: "pino-pretty",
            options: {
                colorize: true,
                translateTime: "SYS:yyyy-mm-dd HH:MM:ss",
                ignore: "pid,hostname"
            }
        }
});
